<?php
$GLOBALS["APP_TITLE"] = "Tbape - Music is nothing else but wild sounds civilized into time and tune";
$GLOBALS["APP_URL"] = "/";
static $content = "";

$request = $_SERVER['REQUEST_URI'];

switch ($request) {
    case '':
    case $GLOBALS["APP_URL"]:
        require 'views/store.php';
        break;
    case $GLOBALS["APP_URL"] . 'store':
        require 'views/store.php';
        break;
    case $GLOBALS["APP_URL"] . 'login':
        require 'views/login.php';
        break;
    case $GLOBALS["APP_URL"] . 'register':
        require 'views/register.php';
        break;
    case $GLOBALS["APP_URL"] . 'logout':
        setcookie('EMAIL', $username, time() - 60 * 60 * 24 * 7);
        header("Location: " . $GLOBALS["APP_URL"]);
        break;
    case $GLOBALS["APP_URL"] . 'uhoh':
        require 'views/uhoh.php';
        break;
    default:
        http_response_code(404);
        require 'views/404.php';
}