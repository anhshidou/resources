<nav class="navbar is-primary is-spaced">
  <div class="navbar-brand image is-64x64">
    <a href="<?php echo $GLOBALS["APP_URL"]; ?>"><img src='images/bape.png'></a>
  </div>
  <div class="navbar-start is-expanded">
    <form action="store" method="POST">
      <div class="field is-grouped">
        <p class="control is-expanded">
          <input class="input is-large floral-white" type="text" name="artist" placeholder="Enter an Artist to Look Up">
        </p>
        <p class="control">
          <button type="submit" class="button is-large is-primary">🔍Search</button>
        </p>
      </div>
    </form>
  </div>
  
  <div class="navbar-end">
    <div class="navbar-item">
      <div class="buttons">
        <?php
          if(!isset($_COOKIE["EMAIL"])) {
              echo '<a class="button is-primary has-text-white" onclick="displayRegistration()">';
              echo '  <strong>Sign up</strong>';
              echo '</a>';
              echo '<a class="button is-light" onclick="displayLogin()">';
              echo '  Log in';
              echo '</a> ';
          } else {
            echo '<div class="navbar-item"><strong class="has-text-white">' . $_COOKIE["EMAIL"] . '</strong></div>';
            echo '<a class="button is-light" href="' . $GLOBALS["APP_URL"]. 'logout">';
            echo '  Logout';
            echo '</a>' ;
          }
        ?>
      </div>
    </div>
  </div>
</nav>