<?php
  if(isset($_COOKIE["MESSAGE"])) {
    echo '<div class="notification" id="notification">';
    echo '  <button class="delete" onclick="closeNotification()"></button>';
    echo '  '. $_COOKIE["MESSAGE"];
    echo '</div>';
    setcookie('MESSAGE', "", time() - 60 * 60 * 24 * 7);
  }
?>