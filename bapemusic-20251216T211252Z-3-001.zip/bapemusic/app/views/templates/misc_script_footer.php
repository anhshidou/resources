<script>
  function removeOverlay(){
    var overlay = document.getElementById('overlay');
    overlay.parentNode.removeChild(overlay);
  }

  function displayRegistration() {
    var overlay = document.createElement("div");
    overlay.className = "overlay";
    overlay.id = "overlay";
    document.getElementsByTagName('body')[0].appendChild(overlay);
    overlay.classList.add("fadein");
    var dialog = document.createElement("div");
    dialog.className = "modal is-active";
    dialog.id = "modalBox";
    var dialogHTML = `
    <div class="modal-card">
    <div class="modal-card-head">
      <a id='close-overlay' onclick="removeOverlay()">&#x2715;</a>
    </div>
    <div class="modal-card-body">
    `;

    dialogHTML += `<form method="post" class="form" action="<?php echo $GLOBALS["APP_URL"] ?>register">`;
    dialogHTML += `<h3 class="title has-text-centered">Sign Up</h3>`;
    dialogHTML += buildInput('Email', 'email');
    dialogHTML += buildInput('Password', 'password');
    dialogHTML += buildInput('Retype Password', 'password');
    dialogHTML += `<div class="field has-text-right">`;
    dialogHTML += `  <div class="control">`;
    dialogHTML += `    <button class="button is-primary">Join</button>`;
    dialogHTML += `  </div>`;
    dialogHTML += `</div>`;
    dialogHTML += `</form>`;

    dialogHTML += `</div>`;
    dialog.innerHTML = dialogHTML;

    document.getElementById('overlay').appendChild(dialog);
  }

  function displayLogin() {
    var overlay = document.createElement("div");
    overlay.className = "overlay";
    overlay.id = "overlay";
    document.getElementsByTagName('body')[0].appendChild(overlay);
    overlay.classList.add("fadein");
    var dialog = document.createElement("div");
    dialog.className = "modal is-active";
    dialog.id = "modalBox";
    var dialogHTML = `
    <div class="modal-card">
    <div class="modal-card-head">
      <a id='close-overlay' onclick="removeOverlay()">&#x2715;</a>
    </div>
    <div class="modal-card-body">
    `;

    dialogHTML += `<form method="post" class="form" action="<?php echo $GLOBALS["APP_URL"] ?>login">`;
    dialogHTML += `<h3 class="title has-text-centered">Log In</h3>`;
    dialogHTML += buildInput('Email', 'email');
    dialogHTML += buildInput('Password', 'password');
    dialogHTML += `<div class="field has-text-right">`;
    dialogHTML += `  <div class="control">`;
    dialogHTML += `    <button class="button is-primary">Login</button>`;
    dialogHTML += `  </div>`;
    dialogHTML += `</div>`;
    dialogHTML += `</form>`;

    dialogHTML += `</div>`;
    dialog.innerHTML = dialogHTML;

    document.getElementById('overlay').appendChild(dialog);
  }


  function buildInput(placeholder, type) {
    contents = '';
    contents += `<div class="field is-horizontal">`;
    contents += `  <div class="field-body">`;
    contents += `    <div class="field">`;
    contents += `      <p class="control">`;
    contents += `        <input class="input" name="`+type+`" type="`+type+`" placeholder="`+placeholder+`">`;
    contents += `      </p>`;
    contents += `    </div>`;
    contents += `  </div>`;
    contents += `</div>`;
    return contents;
  }

  function closeNotification() {
    let notification = document.getElementById("notification");
    let parent = notification.parentNode;
    parent.removeChild(notification);
  }
</script>