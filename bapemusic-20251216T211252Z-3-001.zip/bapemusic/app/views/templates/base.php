<!DOCTYPE html>
<!--[if lt IE 7]>    <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>     <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>     <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js"> <!--<![endif]-->
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title><?php echo $GLOBALS['APP_TITLE'] ?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="stylesheets/bulma/bulma.css">
    <link rel="stylesheet" href="stylesheets/main.css">
    <!-- <script src="js/html2canvas.js"></script> -->
    <?php require __DIR__ . '/misc_script_header.php'; ?>
  </head>
  <body>
    <?php require __DIR__ . '/header.php'; ?>
    <?php require __DIR__ . '/messages.php'; ?>

    <?php echo $content; ?>
    
    <footer class="footer">
      <div class="content has-text-centered">
        <p>
          <strong><?php echo $GLOBALS['APP_TITLE'] ?></strong> by <a href="https://youtu.be/FRz6XT9WPYA">Tbape</a>
        </p>
       
      </div>
    </footer>
    <?php require __DIR__ . '/misc_script_footer.php'; ?>
  </body>
</html>