<?php
  $content .= "<section class='section'>";
  $content .= "  <figure class='image is-64x64'><img src='images/bape_sad.png'></figure>";
  $content .= "  <h1 class='title'>Registration Disabled</h1>";
  $content .= "  <h2 class='subtitle'>";
  $content .= "    Sorry about that!";
  $content .= "  </h2>";
  $content .= "</section>";
  require __DIR__ . '/templates/base.php';
?>