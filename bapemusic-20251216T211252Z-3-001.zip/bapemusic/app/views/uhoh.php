<?php
  $content .= "<section class='section'>";
  $content .= "  <figure class='image is-64x64'><img src='images/bape_sad.png'></figure>";
  $content .= "  <h1 class='title'>Oops...</h1>";
  $content .= "  <h2 class='subtitle'>";
  $content .=     $_COOKIE["ERROR"];
  $content .= "  </h2>";
  $content .= "</section>";
  setcookie('ERROR', "", time() - 60 * 60 * 24 * 7);
  require __DIR__ . '/templates/base.php';
?>