<?php
  $content .= "<section class='section'>";
  $content .= "  <figure class='image is-64x64'><img src='images/antoine.png'></figure>";
  $content .= "  <h1 class='title'>Oops...</h1>";
  $content .= "  <h2 class='subtitle'>";
  $content .= getenv("FLAG");
  $content .= "  </h2>";
  $content .= "  <p>Please be sure to support your favorite creators!</p>";
  $content .= "</section>";
  setcookie('ERROR', "", time() - 60 * 60 * 24 * 7);
  require __DIR__ . '/templates/base.php';
?>