<?php
  if(isset($_POST["email"]) && isset($_POST["password"])) {
    $connection = new mysqli(getenv("DB_HOSTNAME"), getenv("DB_USERNAME"), getenv("DB_PASSWORD"), getenv("DB_DATABASE"));
    if ($connection->error){
      setcookie('ERROR', $connection->error, time() + 60 * 60 * 24 * 7);
      header("Location: ". $GLOBALS["APP_URL"] . "uhoh");
    }

    $email = $connection->real_escape_string($_POST["email"]);
    $password = $connection->real_escape_string($_POST["password"]);
    $query = $connection->prepare("SELECT * FROM employee WHERE email=? AND password=?");
    $query->bind_param("ss", $email, $password);
    $query->execute();
    $result = $query->get_result();

    if (!$result) die($connection->error);
    elseif ($result->num_rows) {
      // $row = $result->fetch_assoc();
      // echo $row;
      // setcookie('EMAIL', $email, time() + 60 * 60 * 24 * 7);
      // header("Location: " . $GLOBALS["APP_URL"]);
      require __DIR__ . '/they_found_the_flag.php';
    } else {
      setcookie('ERROR', "Invalid Email", time() + 60 * 60 * 24 * 7);
      header("Location: " . $GLOBALS["APP_URL"] . 'uhoh');
      // $error_msg = "Invalid Email";
      // require __DIR__ . '/uhoh.php';
    }
  }
?>