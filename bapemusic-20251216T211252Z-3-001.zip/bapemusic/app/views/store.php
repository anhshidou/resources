<?php
  if($_SERVER["REQUEST_METHOD"] == "GET") {
    $connection = new mysqli(getenv("DB_HOSTNAME"), getenv("DB_USERNAME"), getenv("DB_PASSWORD"), getenv("DB_DATABASE"));
    if ($connection->error){
      setcookie('ERROR', $connection->error, time() + 60 * 60 * 24 * 7);
      header("Location: ". $GLOBALS["APP_URL"] . "uhoh");
    }
    $query = "SELECT DISTINCT name FROM artist ORDER BY name;";
    $result = $connection->query($query);
    $rows = $result->num_rows;
    $musical_artists = array();
    for ($i=1; $i <= $rows; $i++) { 
      $result->data_seek($i-1);
      $row = $result->fetch_assoc();
      $artist = $row["name"];
      if(strlen($artist) <= 15) {
        $musical_artists[] = $artist;
      }
    }

    $random_artist = $musical_artists[array_rand($musical_artists)];

    $content .= "<section class='hero is-fullheight-with-navbar bape-bg'>";
    $content .= "  <div class='hero-body'>";
    $content .= "    <div class=''>";
    $content .= "      <p class='title white-text is-size-1'>";
    $content .= "        Tbape's Premiere Audio Streaming Service!";
    $content .= "      </p>";
    $content .= "      <p class='subtitle white-text is-size-3'>";
    $content .= "        Search your favorite artists like <strong>".$random_artist."</strong> to see our selection";
    $content .= "      </p>";
    $content .= "    </div>";
    $content .= "  </div>";
    $content .= "</section>";
  } else { // POST
    $connection = new mysqli(getenv("DB_HOSTNAME"), getenv("DB_USERNAME"), getenv("DB_PASSWORD"), getenv("DB_DATABASE"));
    if ($connection->error){
      setcookie('ERROR', $connection->error, time() + 60 * 60 * 24 * 7);
      header("Location: ". $GLOBALS["APP_URL"] . "uhoh");
    }

    $query = "SELECT artist.name AS artist, album.title AS album, track.name AS track, track.unitprice As price FROM artist JOIN album ON artist.artistid=album.artistid JOIN track ON album.albumid=track.albumid WHERE track.composer LIKE \"%" . $_POST["artist"] . "%\"";
    $query = "SELECT artist.name AS artist, album.title AS album, track.name AS track, track.unitprice As price FROM artist JOIN album ON artist.artistid=album.artistid JOIN track ON album.albumid=track.albumid WHERE track.composer = \"" . $_POST["artist"] . "\"";
    try {
      $result = $connection->query($query);

      $rows = $result->num_rows;

      if(!$result) {
        setcookie('ERROR', $connection->error, time() + 60 * 60 * 24 * 7);
        header("Location: ". $GLOBALS["APP_URL"] . "uhoh");
      }

      if($rows > 0) {
        $content .= "<section class='section'>";
        $content .= "<div class='columns'>";
        for ($i=1; $i <= $rows; $i++) { 
          $result->data_seek($i-1);
          $row = $result->fetch_assoc();
          $content .= "<div class='column is-one-quarter'>";
          $content .= "<div class='card'>";
          $content .= "<div class='card-content'>";
          $content .= "<div class='media is-4'>";
          $content .= "<div class='media-content'>";

          $content .= "<p class='subtitle'>Artist: ".$row["artist"]."</p>";
          $content .= "<p class='subtitle'>Album: ".$row["album"]."</p>";
          $content .= "<p class='subtitle'>Track: ".$row["track"]."</p>";
          $content .= "<footer class='card-footer'>";
          //$content .= "<p class='card-footer-item'>Price: ".$row["Price"]."</p>";
          $content .= "<a href='#' class='card-footer-item is-primary'>Listen ▶</a>";
          $content .= "</footer>";

          $content .= "</div>"; // media-content
          $content .= "</div>"; // media
          $content .= "</div>"; // card-content
          $content .= "</div>"; // card
          $content .= "</div>"; // column

          if($i % 4 === 0) {
            $content .= "</div>"; // columns
            $content .= "<div class='columns'>";
          }
        }
        $content .= "</div>"; //columns
        $content .= "</section>";
      } else {
        $content .= "<section class='section'>";
        $content .= "  <figure class='image is-64x64'><img src='images/bape_sad.png'></figure>";
        $content .= "  <h1 class='title'>Oops...</h1>";
        $content .= "  <h2 class='subtitle'>";
        $content .= "    Unfortunately, that artist does not appear to be in our list.";
        $content .= "  </h2>";
        $content .= "</section>";
      }
    } catch (Exception $e) {
      setcookie('ERROR', $e->getMessage(), time() + 60 * 60 * 24 * 7);
      header("Location: ". $GLOBALS["APP_URL"] . "uhoh");
      // $error_msg = $e->getMessage();
      // require __DIR__ . '/uhoh.php';
    }

  }
  require __DIR__ . '/templates/base.php';
?>