# WolfHowl

A website susceptible to SQL injection via the search box. The webpage also has a login red herring to think the attack uses the -1 attack or manipulating the cookies. Instead, the attacker **must** use SQL to extract a user's credentials and log in to obtain the flag.

In order to gain access to the flag, the attacker will need to exploit the Search bar at the top of the screen. Specifically, the search uses an unescaped query to make its `SELECT` statement across musical artists. The attacker in turn needs to use `UNION` to first identify how many columns are returned in the query. Then, they need to determine which DBMS the server is using. Finally, they'll need to explore the tables and columns to find the email and passwords from the `employee` table.

Once they're found this information, they can log into the website, where they will be immediately greeted with the flag.


## Deployment

Run `docker-compose up --build` to build the image.

Docker should have loaded the `ctf23` database into MySQL, but to make sure...

Run `docker ps` to identify the name of the MySQL container (should be similar to `wolfhowl-mysql-1`).

Then:

* Run `docker exec -ti [NAME OF MYSQL CONTAINER] bash`. 
* Inside the bash, run `mysql -uroot -pUSJeea7hqUZK38E7Bnv4`
* Inside MySQL, type `use ctf23;`
* Finally, `show tables;` to confirm the database has been loaded into MySQL

Then share the URL to the user.