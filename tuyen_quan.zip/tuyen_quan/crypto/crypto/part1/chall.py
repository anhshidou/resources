from random import Random, randint 

SECRET_FLAG = "TBCM{REDACTED"
SECRET_BLOCK_SIZE = 3 

def to_identity_map(a):
    if a.isalpha():
        return ord(a.upper()) - 0x41
    return 0 

def from_identity_map(a):
    return chr(a % 26 + 0x41)

def transpose(m, block_size):
    transposed_m = ""
    for i in range(0, len(m), block_size):
        block = m[i:i + block_size]
        transposed_m += block[::-1]
    return transposed_m

def substitution(m, seed):
    c = ''
    rng = Random(seed)
    key_stream = [rng.randint(0, 25) for _ in range(len(m))]
    
    key_stream_index = 0
    
    for ch in m:
        if not ch.isalpha():
            ech = ch
        else:
            shift = key_stream[key_stream_index]
            key_stream_index += 1 
            chi = to_identity_map(ch)
            ech = from_identity_map(chi + shift)  
        c += ech
    return c

def encrypt(flag, seed, block_size):
    intermediate_m = transpose(flag, block_size)
    ciphertext = substitution(intermediate_m, seed)
    return ciphertext

if __name__ == '__main__':
    RANDOM_SEED = randint(1, 1000000)
    ENCRYPTED_FLAG = encrypt(SECRET_FLAG, RANDOM_SEED, SECRET_BLOCK_SIZE)
    with open('output.txt', 'w') as f:
        f.write(ENCRYPTED_FLAG)